---
title: "Ellagitannin Oligomers from Eucalyptus camaldulensis Leaves and Their Role in the Detoxification of Aluminum"
description: "Eucalyptus camaldulensisof the Myrtaceae family shows high resistance to aluminum (Al) ions and contains various compounds such as steroids, terpenoids, saponins, flavonoids, glycosides, alkaloids, an..."
url: "https://www.mdpi.com/1420-3049/30/10/2216"
type: "paper"
pubDate: "2025-05-19 16:03:04.303957"
created_at: "2025-05-19 16:03:04.316862"
log_id: 25
sourcename: MDPI
author: pendiente
heroImage: /mdpi.jpg
linkDownload: "pendiente"
---

Eucalyptus camaldulensisof the Myrtaceae family shows high resistance to aluminum (Al) ions and contains various compounds such as steroids, terpenoids, saponins, flavonoids, glycosides, alkaloids, and tannins. Although the ellagitannin oenothein B (12) isolated fromE. camaldulensisexhibits remarkable properties for[...] Read more.
