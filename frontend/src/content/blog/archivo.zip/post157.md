---
title: "Milpa Diet for MASLD in Mesoamerican Populations: Feasibility, Advantages, and Future Perspectives"
description: "Metabolic dysfunction-associated steatotic liver disease (MASLD) is the leading cause of chronic liver disease, linked closely to metabolic syndrome and rising obesity rates. Affecting up to 37% of th..."
url: "https://www.mdpi.com/2075-1729/15/5/812"
type: "paper"
pubDate: "2025-05-19 16:03:04.306084"
created_at: "2025-05-19 16:03:04.316862"
log_id: 25
sourcename: MDPI
author: pendiente
heroImage: /mdpi.jpg
linkDownload: "pendiente"
---

Metabolic dysfunction-associated steatotic liver disease (MASLD) is the leading cause of chronic liver disease, linked closely to metabolic syndrome and rising obesity rates. Affecting up to 37% of the global adult population, MASLD prevalence is exceptionally high among individuals of Hispanic descent, with[...] Read more.
