---
title: "Melanoma Glycome Regulates the Pro-Oncogenic Properties of Extracellular Galectin-3"
description: "Metastatic melanoma is an aggressive skin cancer with a five-year survival rate of only 35%. Despite recent advances in immunotherapy, there is still an urgent need for the development of innovative t..."
url: "https://www.mdpi.com/1422-0067/26/10/4882"
type: "paper"
pubDate: "2025-05-19 16:03:04.304603"
created_at: "2025-05-19 16:03:04.316862"
log_id: 25
sourcename: MDPI
author: pendiente
heroImage: /mdpi.jpg
linkDownload: "pendiente"
---

Metastatic melanoma is an aggressive skin cancer with a five-year survival rate of only 35%. Despite recent advances in immunotherapy, there is still an urgent need for the development of innovative therapeutic approaches to improve clinical outcomes of patients with metastatic melanoma. Prior[...] Read more.
