---
title: "Isolation and Expression Pattern Analysis of Larix olgensis LoNAC5: LoNAC5 Acts as a Positive Regulator of Drought and Salt Tolerance"
description: "NAC transcription factors are a kind of plant specific transcription factor widely distributed in plants, and they play an important role in the process of plant growth and development. According to t..."
url: "https://www.mdpi.com/2223-7747/14/10/1527"
type: "paper"
pubDate: "2025-05-19 16:03:04.304774"
created_at: "2025-05-19 16:03:04.316862"
log_id: 25
sourcename: MDPI
author: pendiente
heroImage: /mdpi.jpg
linkDownload: "pendiente"
---

NAC transcription factors are a kind of plant specific transcription factor widely distributed in plants, and they play an important role in the process of plant growth and development. According to the transcriptome data, a transcription factor with typical NAC characteristics was isolated[...] Read more.
